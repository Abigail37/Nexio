<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

requireLogin();

/*
|--------------------------------------------------------------------------
| Admin product access
|--------------------------------------------------------------------------
*/

$allowedRoles = [
    'superuser',
    'ceo',
    'manager'
];

if (!in_array(getUserRole(), $allowedRoles, true)) {
    http_response_code(403);
    exit("Access denied.");
}


/*
|--------------------------------------------------------------------------
| Get all products
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        p.id,
        p.name,
        p.description,
        p.price,
        p.stock_quantity,
        p.image_url,
        p.is_active,
        p.created_at,
        c.name AS category_name
    FROM products p
    LEFT JOIN categories c
        ON p.category_id = c.id
    ORDER BY p.created_at DESC
");

$products = $stmt->fetchAll();


$pageTitle = "Products";

require_once "includes/admin-header.php";
require_once "includes/admin-sidebar.php";

?>


<div class="container">

    <div class="page-inner">
        <!-- breadcrumbs -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Products</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="dashboard.php">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Products</a>
                    </li>
                </ul>
            </div>
            <!-- <div>

                    <h1>Products</h1>
                    <h3 class="fw-bold">
                        Product Management
                    </h3>

                    <p class="text-muted">
                        Manage products in your store.
                    </p>

                </div> -->
            <a
                href="add-product.php"
                class="btn btn-primary btn-round" style="margin-top: -35px;">
                <!-- <i class="fas fa-plus"></i> -->
                Add Product
            </a>

        </div>
        <!-- products table -->
        <div class="card card-round">
            <div class="card-header">
                <div class="card-title">
                    Products
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="basic-datatables" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if (empty($products)): ?>
                                <tr>
                                    <td colspan="6" class="text-center">
                                        No products found.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($products as $product): ?>
                                    <tr>
                                        <td> <?= (int) $product['id'] ?> </td>
                                        <td>
                                            <strong>
                                                <?= htmlspecialchars($product['name']) ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars($product['category_name']?? 'Uncategorized') ?>
                                        </td>
                                        <td>
                                            ₦<?= number_format((float) $product['price'], 2) ?>
                                        </td>
                                        <td>
                                            <?= (int) $product['stock_quantity'] ?>
                                        </td>
                                        <td>
                                            <?php if ((int) $product['is_active'] === 1): ?>
                                                <span class="badge badge-success">
                                                    Active
                                                </span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">
                                                    Inactive
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>




<?php require_once "includes/admin-footer.php"; ?>