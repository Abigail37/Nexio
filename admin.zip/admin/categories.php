<?php

require_once "../includes/db.php";
require_once "includes/admin-header.php";
require_once "includes/admin-sidebar.php";


$success = "";
$error = "";
/*
|--------------------------------------------------------------------------
| Fetch active categories
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        id,
        name,
        description
    FROM categories
    WHERE is_active = 1
    ORDER BY name ASC
");

$categories = $stmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Handle category creation
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $isActive = isset($_POST['is_active']) ? 1 : 0;


    /*
    |--------------------------------------------------------------------------
    | Validate name
    |--------------------------------------------------------------------------
    */

    if ($name === '') {

        $error = "Category name is required.";
    } else {

        /*
        |--------------------------------------------------------------------------
        | Check for duplicate category
        |--------------------------------------------------------------------------
        */

        $checkStmt = $pdo->prepare("
            SELECT id
            FROM categories
            WHERE name = :name
            LIMIT 1
        ");

        $checkStmt->execute([
            ':name' => $name
        ]);

        if ($checkStmt->fetch()) {

            $error = "A category with this name already exists.";
        } else {

            /*
            |--------------------------------------------------------------------------
            | Insert category
            |--------------------------------------------------------------------------
            */

            try {

                $stmt = $pdo->prepare("
                    INSERT INTO categories (
                        name,
                        description,
                        is_active
                    )
                    VALUES (
                        :name,
                        :description,
                        :is_active
                    )
                ");

                $stmt->execute([
                    ':name' => $name,
                    ':description' =>
                    $description !== ''
                        ? $description
                        : null,
                    ':is_active' => $isActive
                ]);

                $success = "Category created successfully.";

                /*
                |--------------------------------------------------------------------------
                | Clear form
                |--------------------------------------------------------------------------
                */

                $_POST = [];
            } catch (PDOException $e) {

                $error = "Unable to create category.";
            }
        }
    }
}
?>


<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Categories</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="dashboard.php">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Category</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Add Category</div>
                        <!-- <p>Add a new product to your inventory.</p> -->
                    </div>
                    <div class="card-body">

                        <?php if ($success !== ''): ?>
                            <div class="success-message">
                                <?= htmlspecialchars($success) ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($error !== ''): ?>
                            <div class="error-message">
                                <?= htmlspecialchars($error) ?>
                            </div>
                        <?php endif; ?>
                        <?php if (empty($categories)): ?>
                            <div class="error-message">
                                No active categories are available.
                                Please create a category first.

                                <br><br>
                                <a href="categories.php">
                                    Add Category
                                </a>
                            </div>
                        <?php else: ?>
                            <form method="POST" action="categories.php">
                                <div class="row">
                                    <!-- PRODUCT NAME -->
                                    <div class="col-md-6 col-lg-12">
                                        <div class="form-group">
                                            <label for="name">Category Name</label>
                                            <input
                                                type="text"
                                                id="name"
                                                name="name"
                                                value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                                                placeholder="Enter category name"
                                                class="form-control"
                                                required />
                                        </div>
                                    </div>
                                    <!-- DESCRIPTION -->
                                    <div class="col-md-6 col-lg-12">
                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea
                                                id="description"
                                                name="description"
                                                rows="4"
                                                class="form-control"
                                                placeholder="Enter category description"><?= htmlspecialchars($_POST['description'] ?? '') ?>
                                            </textarea>
                                        </div>
                                    </div>
                                    <!-- ACTIVE CATEGORY -->
                                    <div class="col-md-6 col-lg-2">
                                        <div class="form-group checkbox-group">
                                            <label>
                                                <input
                                                    type="checkbox"
                                                    name="is_active"
                                                    value="1"
                                                    checked>
                                                Active Category
                                            </label>
                                        </div>
                                    </div>
                                    <!-- SUBMIT -->
                                    <div class="col-md-6 col-lg-2">
                                        <button
                                            type="submit"
                                            class="btn btn-dark btn-round">
                                            Add Category
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>


        <?php if (empty($categories)): ?>
            <div class="empty-state">
                <h2> No categories available </h2>
                <p>Categories will appear here when they are added. </p>
            </div>
        <?php else: ?>


            <div class="card card-round">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="display table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if (empty($categories)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">
                                            No categories found.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($categories as $category): ?>
                                        <tr>
                                            <td> <?= (int) $category['id'] ?> </td>
                                            <td>
                                                <strong>
                                                    <?= htmlspecialchars($category['name']) ?>
                                                </strong>
                                            </td>
                                            <td>
                                                <?php if (!empty($category['description'])): ?>
                                                    <p>
                                                        <?= htmlspecialchars(
                                                            $category['description']
                                                        ) ?>
                                                    </p>
                                                <?php else: ?>
                                                    <p>
                                                        Browse products in this category.
                                                    </p>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span>
                                                    <a href="products.php" class="btn btn-primary btn-round btn-icon"><i class="fas fa-eye"></i></a>
                                                    <a href="categories.php?remove=<?= (int) $category['id'] ?>" class="btn btn-danger btn-round btn-icon"><i class="fas fa-trash"></i></a>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once "includes/admin-footer.php"; ?>